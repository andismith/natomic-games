V 0.2

New grahpics
New gun
Lots of bugs fixed

This is just a demo
to show off the platform
movement.

Made by Jake

All material copyright (c) 2000 Jake - http://www.natomic.com