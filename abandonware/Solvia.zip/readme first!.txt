Thanks for downloading the Solvia: Graveyard Edition.

This is what i could find of the now year old Solvia engine.

This is most of what i got done on the battle engine, however there is more lying around somewhere. Feel free to leave comments/rants/etc, but i won't be able to continue this project because i have lost the source file :o

Also, you cannot use the graphics because they are drawn by Ironshins and i don't have his permision to use them for free.

Controls:

Shift: Confirm
Arrows: Move Cursors
Ctrl: Cancel

On the test screen, name the characters, set up a hero and enemy party, and hit begin.

You cannot kill any enemies, all you can do is attack/run in a loop. The magic/item lists work, but you can't use them. This is only a small bit of the battle engine.

If i get any comments about not being able to kill enemies i will be angry! <:)

_______________

Blake Edwards

email-
blake@natomic.com