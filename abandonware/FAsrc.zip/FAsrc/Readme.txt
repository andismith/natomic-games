Foreign Amulet

Famulet is an abandonware game made in early 2002 intended to be merely a test, but later evolved into my main project. After working on it thoroughly I got tired of the engine. The character was called Vaugh Liblen, who was an agent trapped in a house with monsters, and then, eventually, realizes that the town might be in geopardy. The gameplay was first meant to be action-wise, but later went to strategy and adventure.
I am not willing to work on this anymore.

1, 2, 3 and 4 (I think) work for weapons. 
You shoot with Control. 
You jump with shift.
You use the mouse to select different options at the menu bar.
You press Z while swimming to dive a little.

This is not a game, for it's too short. I'd prefer to call it an engine test :)
The enemy's AI is definitively very poor, but I abandoned this project soon after creating it.

If somebody is interested in going on with the project, that'd make me very happy. Just tell me you're doing so.

If you want any sort of information regarding this game, please contact me.

Sincerely,
Alonso Martin
vaughliblen@hotmail.com
http://www.natomic.com

-update-
Took away the task priority object