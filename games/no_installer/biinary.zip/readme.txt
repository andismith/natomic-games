BII-NARY
The War Against Pop Ups

STORY----

A few months have passed since the Natomic Website was overun by a deadly virus threatening to destroy all the team had worked for. Thanks to BI-NARY, the threat was diminished and the website saved. But it still wasn't without it's troubles. With Datastream seemingly lost in the void known as the Internet, the team sought out a new host for the site, coming across the Free service called TRO-JAN. Obviously not taking heed of the name, the site suddenly becomes infested with Pop-Up's threatening to send all their adoring fans away! And it seems the pop-ups aren't the only problem as the deadly virus has returned. With the clock ticking on the sites demise, BI-NARY must once again save the site by entering the source of the infestation! The War Against Pop-Up's ends now!...

CONTROLS----
Cursor keys to move left and right
Shift to shoot
Control to jump

More games available at http://www.natomic.com