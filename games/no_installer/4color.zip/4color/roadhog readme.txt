Roadhog -- Natomic Studios -- www.natomic.com

Controls:

Click GO! to start the man crossing the road.
Avoid the cars - get to the other side.

Info:

Game made in 4 colors for Total Klik compo.  Music from MegaMan X.  Game By Andi.



