Zoom! -- Natomic Studios -- www.natomic.com

Basic Controls:

Ctrl       : Shoot
Arrow Keys : Move

Info:

Game made in 4 colors for Total Klik compo.  Music By Yoshiman.  Rest of Game By Akira.



