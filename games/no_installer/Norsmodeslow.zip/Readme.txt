---------------------
Nors Mode v1.0 by Odi
---------------------

Controls -

Z = Fire Heavy Cannon
Cursor Keys = Move
Use your beam weapon to destroy incoming bullets and missiles to nab extra points. Also Blue fighters can be destroyed by the beam for bonus points

Please Note: Due to the digital music and Mode 7 effects some slower PC's will not run Nors Mode correctly. A toned down version of the game will be available in the near future.

Credits:

*Game design and spriting by Odi
*Online score code with help from Blake
*Intro Midi by Odi
*XM created by Y0da (Used in Nors Mode with full permission)

Copyright Chris Giles, Natomic Studios 2003
http://www.natomic.com