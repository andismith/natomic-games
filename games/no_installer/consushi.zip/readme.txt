

 ===========================
 |                         |
 |    Guakamole Con Sushi  |
 |                         |
 ===========================

by Ndeal (fourthq@hotmail.com) , Pegwo, and Blake (blake_eat_world@ny.com)

- created in Multimedia Fusion

www.natomic.com