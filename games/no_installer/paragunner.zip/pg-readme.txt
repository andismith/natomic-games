Paragunner - v1.8
Made By. Richard Hodgson
Natomic Studios � 2002
http://www.natomic.com

This game is FREEWARE and should be distributed freely.


---CONTROLS---
 
Direction Keys - Move 

Space - Shoot

---OTHER INFO---

This game was created in The Games Factory (www.clickteam.com).

All graphics where made by Richard Hodgson. (bottledrichie@hotmail.com)
