Bananarama! -- Natomic Studios -- www.natomic.com

Basic Controls:

Right Dir Key      : Walk Right
Left Dir Key       : Walk Left
Ctrl               : Lay Bomb, Throw Bomb

Each time you beat a Zone (set of 4 levels) your skill level goes up by one.  
In the first levels you can only walk and lay bombs.  Later on you learn other
skills.

Skills: 

Level 1 : Jump 
Level 2 : Throw Bombs
Level 3 : Remote Bombs

Skill Controls:

Shift          : Jump
Up Dir Key     : Pick up Bomb
Enter          : Detonate Remote Bombs



